
'''
This file contains the configs used for Model creation and training. You need to give your best hyperparameters and the configs you used to get the best results for 
every environment and experiment.  These configs will be automatically loaded and used to create and train your model in our servers.
'''
#You can add extra keys or modify to the values of the existing keys in bottom level of the dictionary.
#DONT CHANGE THE OVERALL STRUCTURE OF THE DICTIONARY. 

# configs = {
    
    
    # 'InvertedPendulum-v4': {
    #     "PPO":{
    #         #You can add or change the keys here
    #             "hyperparameters": {
    #                 "total_timesteps": 1000000 ,
    #                 "algorithm": 'PPO',
    #                 "log_interval" : 500,
    #                 "eval_freq" : 5000,
    #                 "save_freq" : 50000,
    #                 "Run_name" :'Run',
                    
    #             },            
    #     },
        
    #      "A2C":{
    #         #You can add or change the keys here
    #             "hyperparameters": {
    #                 "total_timesteps": 1000000,
    #                 "algorithm": 'A2C',
    #                 "log_interval" : 500,
    #                 "eval_freq" : 5000,
    #                 "save_freq" : 50000,
    #                 "Run_name" :'Run',
                    
    #             },            
    #     },
    # },
    
    # 'HalfCheetah-v4': {
        
    #      "PPO":{
    #         #You can add or change the keys here
    #             "hyperparameters": {
    #                 "total_timesteps": 1000000 ,
    #                 "algorithm": 'PPO',
    #                 "log_interval" : 500,
    #                 "eval_freq" : 5000,
    #                 "save_freq" : 50000,
    #                 "Run_name" :'Run',
                    
    #             },            
    #     },
    #      "A2C":{
    #         #You can add or change the keys here
    #             "hyperparameters": {
    #                 "total_timesteps": 1000000,
    #                 "algorithm": 'A2C',
    #                 "log_interval" : 500,
    #                 "eval_freq" : 5000,
    #                 "save_freq" : 50000,
    #                 "Run_name" : 'Run',
              
    #             },            
    #     },
    # },
    
    

    # 'Hopper-v4': {
        
    #    "PPO":{
    #         #You can add or change the keys here
    #             "hyperparameters": {
    #                 "total_timesteps": 1000000 ,
    #                 "algorithm": 'PPO',
    #                 "log_interval" : 500,
    #                 "eval_freq" : 5000,
    #                 "save_freq" : 50000,
    #                 "Run_name" :'Run',
                    
    #             },            
    #     },
    #    "A2C":{
    #         #You can add or change the keys here
    #             "hyperparameters": {
    #                 "total_timesteps": 1000000,
    #                 "algorithm": 'A2C',
    #                 "log_interval" : 500,
    #                 "eval_freq" : 5000,
    #                 "save_freq" : 50000,
    #                 "Run_name" : 'Run',
            
    #             },            
    #     },
    # },
    # }
    
    
configs = {

    'InvertedPendulum-v4': {
        "PPO": {
            "hyperparameters": {
                "total_timesteps": 300_000,        # easy env, fewer timesteps needed
                "algorithm": 'PPO',
                "learning_rate": 3e-4,
                "n_steps": 2048,
                "batch_size": 64,
                "n_epochs": 10,
                "gamma": 0.99,
                "gae_lambda": 0.95,
                "clip_range": 0.2,
                "ent_coef": 0.0,
                "vf_coef": 0.5,
                "max_grad_norm": 0.5,
                "policy": "MlpPolicy",
                "policy_kwargs": {
                    "net_arch": [dict(pi=[64, 64], vf=[64, 64])]
                },
                "log_interval": 500,
                "eval_freq": 5_000,
                "save_freq": 50_000,
                "Run_name": 'PPO_InvertedPendulum',
                "seeds": [0, 1, 2],
                "tensorboard_log": "./tensorboard_logs",
                "device": "cuda",                  # if GPU available
                "use_lr_scheduler": True,
                "lr_schedule": "linear"            # common choice for PPO
            },
        },

        "A2C": {
            "hyperparameters": {
                "total_timesteps": 300_000,
                "algorithm": 'A2C',
                "learning_rate": 7e-4,
                "n_steps": 5,                      # A2C typically uses small n_steps
                "gamma": 0.99,
                "gae_lambda": 0.95,
                "ent_coef": 0.01,
                "vf_coef": 0.5,
                "max_grad_norm": 0.5,
                "policy": "MlpPolicy",
                "policy_kwargs": {
                    "net_arch": [64, 64]
                },
                "log_interval": 500,
                "eval_freq": 5_000,
                "save_freq": 50_000,
                "Run_name": 'A2C_InvertedPendulum',
                "seeds": [0, 1, 2],
                "tensorboard_log": "./tensorboard_logs",
                "device": "cuda",
                "use_lr_scheduler": True,
                "lr_scheduler_cfg": {              # optional scheduler config
                    "type": "StepLR",
                    "step_size": 50,
                    "gamma": 0.9
                }
            },
        },
    },

    'HalfCheetah-v4': {

        "PPO": {
            "hyperparameters": {
                "total_timesteps": 1_000_000,
                "algorithm": 'PPO',
                "learning_rate": 3e-4,
                "n_steps": 2048,
                "batch_size": 256,
                "n_epochs": 10,
                "gamma": 0.99,
                "gae_lambda": 0.95,
                "clip_range": 0.2,
                "ent_coef": 0.0,
                "vf_coef": 0.5,
                "max_grad_norm": 0.5,
                "policy": "MlpPolicy",
                "policy_kwargs": {
                    "net_arch": [256, 256]
                },
                "log_interval": 500,
                "eval_freq": 10_000,
                "save_freq": 50_000,
                "Run_name": 'PPO_HalfCheetah',
                "seeds": [0, 1, 2],
                "tensorboard_log": "./tensorboard_logs",
                "device": "cuda",
                "use_lr_scheduler": True,
                "lr_schedule": "linear"
            },
        },
        "A2C": {
            "hyperparameters": {
                "total_timesteps": 1_000_000,
                "algorithm": 'A2C',
                "learning_rate": 7e-4,
                "n_steps": 20,                     # larger n_steps for continuous control
                "gamma": 0.99,
                "gae_lambda": 0.95,
                "ent_coef": 0.01,
                "vf_coef": 0.5,
                "max_grad_norm": 0.5,
                "policy": "MlpPolicy",
                "policy_kwargs": {
                    "net_arch": [256, 256]
                },
                "log_interval": 500,
                "eval_freq": 10_000,
                "save_freq": 50_000,
                "Run_name": 'A2C_HalfCheetah',
                "seeds": [0, 1, 2],
                "tensorboard_log": "./tensorboard_logs",
                "device": "cuda",
                "use_lr_scheduler": True,
                "lr_scheduler_cfg": {
                    "type": "StepLR",
                    "step_size": 100,
                    "gamma": 0.95
                }
            },
        },
    },

    'Hopper-v4': {

       "PPO": {
            "hyperparameters": {
                "total_timesteps": 1_000_000,
                "algorithm": 'PPO',
                "learning_rate": 3e-4,
                "n_steps": 2048,
                "batch_size": 64,
                "n_epochs": 10,
                "gamma": 0.99,
                "gae_lambda": 0.95,
                "clip_range": 0.2,
                "ent_coef": 0.01,
                "vf_coef": 0.5,
                "max_grad_norm": 0.5,
                "policy": "MlpPolicy",
                "policy_kwargs": {
                    "net_arch": [256, 256]
                },
                "log_interval": 500,
                "eval_freq": 10_000,
                "save_freq": 50_000,
                "Run_name": 'PPO_Hopper',
                "seeds": [0, 1, 2],
                "tensorboard_log": "./tensorboard_logs",
                "device": "cuda",
                "use_lr_scheduler": True,
                "lr_schedule": "linear"
            },
        },
       "A2C": {
            "hyperparameters": {
                "total_timesteps": 1_000_000,
                "algorithm": 'A2C',
                "learning_rate": 7e-4,
                "n_steps": 20,
                "gamma": 0.99,
                "gae_lambda": 0.95,
                "ent_coef": 0.01,
                "vf_coef": 0.5,
                "max_grad_norm": 0.5,
                "policy": "MlpPolicy",
                "policy_kwargs": {
                    "net_arch": [256, 256]
                },
                "log_interval": 500,
                "eval_freq": 10_000,
                "save_freq": 50_000,
                "Run_name": 'A2C_Hopper',
                "seeds": [0, 1, 2],
                "tensorboard_log": "./tensorboard_logs",
                "device": "cuda",
                "use_lr_scheduler": True,
                "lr_scheduler_cfg": {
                    "type": "StepLR",
                    "step_size": 100,
                    "gamma": 0.95
                }
            },
        },
    },
}
