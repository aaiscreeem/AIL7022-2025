import os
import time

import sys
sys.path.append(os.path.join(os.path.dirname(__file__), "../"))

import gymnasium as gym
import numpy as np
import torch

import config as exp_config
import utils.utils as utils
import utils.pytorch_util as ptu
from utils.logger import Logger
from torch.utils.tensorboard import SummaryWriter


def setup_agent(args, configs):
    
    from agents.mujoco_agents import SBAgent as Agent
    global agent, env, writer

    agent = Agent(args.env_name, **configs['hyperparameters'])

    # Create TensorBoard writer
    log_path = f"runs/{args.env_name}_{int(time.time())}"
    writer = SummaryWriter(log_path)

    # attach writer to agent so it can log reward/LR
    agent.writer = writer

    env = agent.env

    # load checkpoint if provided
    if args.load_checkpoint is not None:
        agent.load_checkpoint(args.load_checkpoint)



def train_agent():
    agent.learn()
    agent.writer.close()



def test_agent(args):
    import numpy as np
    import cv2
    from tqdm import tqdm

    print("Starting Testing...")
    obs = env.reset()
    
    image_obs = []
    rewards = []

    for k in tqdm(range(500)):
        action, _ = agent.get_action(obs)
        obs, rew, done, info = env.step(action)
        
        # Capture the frame
        try:
            img = env.render()
            
            # Helper: If VecEnv returns a list of images, take the first one
            if isinstance(img, list):
                img = img[0]
            # Helper: If it returns a 4D array (1, H, W, C), squeeze it
            elif isinstance(img, np.ndarray) and len(img.shape) == 4:
                img = img[0]
                
            image_obs.append(img)
            rewards.append(rew)
        except Exception as e:
            print(f"Render Error: {e}")
            break

    print(f"Mean reward: {np.mean(rewards)}")

    # Save Video
    if len(image_obs) > 0:
        height, width, layers = image_obs[0].shape
        video_name = f'{args.env_name}_seed_{args.seed}_{args.algo}.mp4'
        
        # Initialize Video Writer
        out = cv2.VideoWriter(
            video_name,
            cv2.VideoWriter_fourcc(*'mp4v'),
            30,
            (width, height)
        )

        for frame in image_obs:
            # Convert RGB (Gym) to BGR (OpenCV)
            out.write(cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
        
        out.release()
        print(f"Saved video successfully: {video_name}")
    else:
        print("No frames captured to save.")   


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--env_name', type=str)
    parser.add_argument('--algo', type=str, choices=["A2C", "PPO"], required=True)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--test', action='store_true')
    parser.add_argument('--load_checkpoint', type=str)

    args = parser.parse_args()

    # Select algorithm: PPO or A2C
    configs = exp_config.configs[args.env_name][args.algo]

    # Set seeds
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    setup_agent(args, configs)

    if args.test:
        test_agent(args)
    else:
        train_agent()
        test_agent(args)     # auto-create GIF after training

            
        
    
    















